import unittest
from momo.cli import br

class TestMOMO(unittest.TestCase):

    def setUp(self):
        pass


    def test_lucher(self):
        pass

    def tearDown(self):
        pass

